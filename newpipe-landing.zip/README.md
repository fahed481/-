# NewPipe Landing Page

This is a simple landing page for **NewPipe**, a lightweight YouTube experience.

## Features
- Clean and simple design
- Sections for features, download links, and footer
- Responsive layout

## Deployment
You can deploy this page easily using **GitHub Pages** or **Vercel**.

### GitHub Pages
1. Push this repository to GitHub.
2. Go to **Settings > Pages** and enable GitHub Pages from the `main` branch.
3. Your site will be live at `https://your-username.github.io/newpipe-landing`.

### Vercel
1. Import the repo into [Vercel](https://vercel.com/).
2. Deploy with default settings.
3. Done 🎉

---

© 2025 NewPipe Fan Website
